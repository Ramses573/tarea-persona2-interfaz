# Catálogo de artículos sobre React Native

Proyecto de Programación V, Tarea Corta 3. Aplicación React Native con Expo que consulta artículos de DEV.to, muestra un listado con imágenes y permite filtrar por categoría y marcar favoritos durante la sesión.

## Instalación y ejecución

Requisitos: Node.js 20.19.4 o superior, npm e Internet para consultar DEV.to y cargar las imágenes remotas. La validación de esta entrega se realizó con Node.js 24.19.0 y npm 11.17.0 en Windows.

Desde la raíz del repositorio:

```sh
cd persona2-interfaz
npm ci
npm start
```

Expo mostrará el QR y las opciones para abrir la aplicación. Para la versión web:

```sh
npm run web
```

Para Android o iOS se requiere Expo Go compatible con SDK 54 o un entorno de desarrollo móvil adecuado. El emulador Android necesita el SDK de Android; el simulador de iOS necesita macOS y Xcode. En un teléfono y una computadora, comprobar la conectividad entre ambos. No es necesario configurar una clave de API para esta consulta pública.

## Funcionamiento

1. `App.js` ejecuta `useCatalogItems`.
2. El Hook solicita los artículos mediante `fetchCatalogItems` y administra carga, datos y error.
3. El servicio realiza `GET https://dev.to/api/articles?tag=reactnative&per_page=30`, comprueba HTTP, interpreta JSON y valida que la respuesta sea un arreglo.
4. `HomeScreen` normaliza los artículos y los presenta con `FlatList` e `ItemCard`.
5. `CategoryFilter` filtra las categorías asignadas por el adaptador. Los favoritos se conservan en memoria durante la sesión.

La carga, el error y una respuesta vacía tienen presentaciones distintas. La aplicación integrada utiliza la API. Los datos de prueba solo se activan al usar `HomeScreen` sin las props de API, como demostración aislada de la interfaz.

## Organización

```text
persona2-interfaz/               Aplicación Expo y pruebas automatizadas
  App.js
  src/features/catalog/         Componentes, Hook, servicio y adaptador
  src/shared/styles/            Estilos compartidos
  tests/                        Pruebas del servicio y de navegador
docs/
  desarrollo/Pruebas_Integracion.md
  desarrollo/evidencias/persona4/
  entrega/InvestigacionReactNative.pdf
```

## Pruebas reproducibles

Dentro de `persona2-interfaz`:

```sh
npm test
npx expo install --check
npx expo-doctor
npm run export
npx playwright install chromium
npm run test:web
```

`npm test` ejecuta 12 pruebas aisladas de servicio y adaptación, sin consultar servicios externos. `npm run export` genera JavaScript web y paquetes Hermes para Android e iOS; no genera un APK ni instala una aplicación.

`npm run test:web` inicia un servidor temporal en `127.0.0.1`, abre Chromium sin ventana y ejecuta ocho escenarios con respuestas controladas. Genera capturas y `resultados-web.json` en `docs/desarrollo/evidencias/persona4/`. Para incluir la consulta real a DEV.to:

```sh
npm run test:web -- --live
```

Si se prefiere Google Chrome ya instalado, en PowerShell:

```powershell
$env:PW_CHANNEL = 'chrome'
npm run test:web -- --live
```

Las capturas con artículos de prueba son datos controlados. `09-api-real.png` corresponde a una consulta real. Los resultados pueden variar con la disponibilidad de DEV.to y sus imágenes. La prueba de red interrumpe solamente la petición de la API; no certifica funcionamiento sin conexión de toda la aplicación.

## Resultados y límites

Validación del 5 de noviembre de 2026: **12/12 pruebas de servicio**, **9/9 escenarios web** incluyendo la consulta real, **18/18 comprobaciones de Expo Doctor** y exportación para las tres plataformas. El detalle, la incidencia corregida y los pasos manuales están en [Pruebas de integración](docs/desarrollo/Pruebas_Integracion.md).

Falta ejecutar el recorrido en un teléfono o emulador Android/iOS. Las capturas con ancho móvil corresponden a un navegador, no a un dispositivo nativo. Los favoritos no persisten después de recargar, no hay paginación ni botón de reintento, y las imágenes necesitan conexión. Para repetir una solicitud después de un error, recargar la aplicación.

## Investigación y entrega

- [Investigación grupal con portada](docs/entrega/InvestigacionReactNative.pdf).
- [Pruebas de integración y validación](docs/desarrollo/Pruebas_Integracion.md).
- [Capturas y resultados](docs/desarrollo/evidencias/persona4/).

Este paquete contiene el código integrado, sus pruebas y evidencias, las instrucciones de ejecución y el PDF final. La validación en un teléfono o emulador sigue pendiente. El PDF corresponde al archivo final proporcionado por el equipo.

## Referencias

- [Inicio del desarrollo con Expo](https://docs.expo.dev/get-started/start-developing/).
- [Efectos y limpieza en React](https://react.dev/reference/react/useEffect).
- [Pruebas en React Native](https://reactnative.dev/docs/testing-overview).
- [API de Forem](https://developers.forem.com/api/v1).
